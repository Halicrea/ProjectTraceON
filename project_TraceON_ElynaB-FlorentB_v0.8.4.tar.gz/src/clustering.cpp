/*#########################################
## 26/01/2023
## Par Elyna Bouchereau & Florent Boyer
## Fichier: clustering.cpp
###########################################*/
#include "struct.hpp"
#include "clustering.hpp"
#include "pairwize_global.hpp"
#include <vector>
#include <string>
#include <iostream>
#include <iomanip>

using namespace std;


//##################################################################################
template <typename T> string to_str(const T& t) { 
   ostringstream os; 
   os<< t << setprecision(2) ; 
   return os.str(); 
} 
//********************************************************************************
/*
$$$$$$$$\                                   $$$$$$\                                 $$\               
\__$$  __|                                 $$  __$$\                                $$ |              
   $$ | $$$$$$\   $$$$$$\   $$$$$$\        $$ /  \__| $$$$$$\   $$$$$$\   $$$$$$\ $$$$$$\    $$$$$$\  
   $$ |$$  __$$\ $$  __$$\ $$  __$$\       $$ |      $$  __$$\ $$  __$$\  \____$$\\_$$  _|  $$  __$$\ 
   $$ |$$ |  \__|$$$$$$$$ |$$$$$$$$ |      $$ |      $$ |  \__|$$$$$$$$ | $$$$$$$ | $$ |    $$$$$$$$ |
   $$ |$$ |      $$   ____|$$   ____|      $$ |  $$\ $$ |      $$   ____|$$  __$$ | $$ |$$\ $$   ____|
   $$ |$$ |      \$$$$$$$\ \$$$$$$$\       \$$$$$$  |$$ |      \$$$$$$$\ \$$$$$$$ | \$$$$  |\$$$$$$$\ 
   \__|\__|       \_______| \_______|$$$$$$\\______/ \__|       \_______| \_______|  \____/  \_______|
                                     \______|                                                         
*/
TArbreBin<string>* build_tree(vector<matri> &D_aux, vector<TArbreBin<string>*> &subtrees,
								vector<string> &seq_prec_vector,
								float value, int k, int r){
	//***** INIT VARIABLES ******
	TArbreBin<string>* root;
	bool trouver = false;
	int nb_prec = 0;

	//**** DEBUT ****************
		// If we one of the sequence chosen to pair has been paired before, we had only the new leaf
		nb_prec = seq_prec_vector.size();
		for(int i=0;i<nb_prec;i++){
			cout << seq_prec_vector[i] << "/";
			if(D_aux[r].header == seq_prec_vector[i]){
				int cpt=0;
				while(D_aux[k].header != seq_prec_vector[cpt] && cpt < seq_prec_vector.size()){
					cpt++;
				}
				if(cpt < seq_prec_vector.size()){
					// We have found a match for r and k
					root =  new TArbreBin<string>(to_str<float>(value));
					root -> fg = subtrees[i];
					root -> fd = subtrees[cpt];
					subtrees[cpt] = root;
				} else {
					root =  new TArbreBin<string>(to_str<float>(value));
					root -> fg = subtrees[i];
					root -> fd = new TArbreBin<string>(D_aux[k].header);
					subtrees[i] = root;
					subtrees.push_back(root);
					seq_prec_vector.push_back(D_aux[k].header);	
				}
				trouver = true;	break;
			}
			if(D_aux[k].header == seq_prec_vector[i]){
				int cpt=0;
				while(D_aux[r].header != seq_prec_vector[cpt] && cpt < seq_prec_vector.size()){
					cpt++;
				}
				if(cpt < seq_prec_vector.size()){
					// We have found a match for r and k
					root =  new TArbreBin<string>(to_str<float>(value));
					root -> fg = subtrees[cpt];
					root -> fd = subtrees[i];
					subtrees[i] = root;
				} else {
					root =  new TArbreBin<string>(to_str<float>(value));
					root -> fg = new TArbreBin<string>(D_aux[r].header);
					root -> fd = subtrees[i];
					subtrees[i] = root;
				}
				trouver = true;
				break;
			}
		}
	if(!trouver){
		root =  new TArbreBin<string>(to_str<float>(value));
		root -> fg = new TArbreBin<string>(D_aux[k].header);
		root -> fd = new TArbreBin<string>(D_aux[r].header);
		subtrees.push_back(root);
		seq_prec_vector.push_back(D_aux[k].header);		
	}
	cout << endl;
	//root -> printBTS();
	return root;
}



//####################################################################################
//******************************************************************************
/*
	La méthode utilisée pour calculer la distance entre 2 séquences,
	donne un score d'autant plus élevé que 2 séquences sont
	similaires (les évènements et longues séquences sont favorisés).
*/
void find_maximum(const vector<matri> &D, int &i_min, int &j_min, float &value){

	const int n=D.size();	// Number of sequences
	value = 0;
	for(int i=0;i<n;i++){
		for(int j=0;j<D[i].ligne.size();j++){
			if(value<D[i].ligne[j]){
				value = D[i].ligne[j];

				i_min = i; // Comme la diagonale n'est pas modélisée, les numéros de colonnes sont plus petit de 1
				j_min = j;
			}
		}
	}

}
void supprimer_ligne(vector<matri> &D, const int &r){

	const int n=D.size();	// Number of sequences
	if (n > r){
		D.erase( D.begin() + r );
	}
}
void supprimer_colonne(vector<matri> &D, const int &r){

	const int n=D.size();	// Number of sequences
	for (int i = 0; i < n; i++){
		if (D[i].ligne.size() > r){
			D[i].ligne.erase(D[i].ligne.begin() + r);
  		}
	}
}

float dissim_lign(vector<matri> &D, int i_min, int j_min, int i){
	//TODO Add explanation
	const int n=D.size()-1;	// Number of sequences
	float i_val,j_val;
	float result;

	i_val = D[i_min].ligne[i];

	j_val = D[j_min].ligne[i];


	result = (i_val + j_val)/2;

	return result;
}
float dissim_col(vector<matri> &D, int i_min, int j_min, int i, int &i_save){
	//TODO Add explanation
	const int n=D.size()-1;	// Number of sequences
	int index_i, index_j;
	float i_val,j_val;
	float result;

	if((j_min+i) < D[i_min].ligne.size()){
		i_val = D[i_min].ligne[j_min+i];
		index_i = i_min;
		index_j = j_min+i;
	} else{
		i_save++;
		i_val = D[D[i_min].ligne.size()+i_save].ligne[i_min];
		index_i = D[i_min].ligne.size()+i_save;
		index_j = i_min;
	}

	j_val = D[j_min+1+i].ligne[j_min];

	result = (i_val + j_val)/2;
	return result;
}

//####################################################################################
/*
 $$$$$$\   $$$$$$\  $$\   $$\ 
$$  __$$\ $$  __$$\ $$ |  $$ |
$$ /  \__|$$ /  $$ |$$ |  $$ |
$$ |      $$$$$$$$ |$$$$$$$$ |
$$ |      $$  __$$ |$$  __$$ |
$$ |  $$\ $$ |  $$ |$$ |  $$ |
\$$$$$$  |$$ |  $$ |$$ |  $$ |
 \______/ \__|  \__|\__|  \__|                         
*/
//TODO Needs to add a way to save the tree and print it
void CAH(vector<matri> &D, TArbreBin<string>* &root,
		string &name_remove, string &name_kept,
		float &score_pair){
	int n=D.size();	// Number of sequences
	vector<matri> D_aux = D;
	int i_min,j_min = 0;
	int i_save, r, k;
	TArbreBin<string>* root_prec;
	vector<TArbreBin<string>*> subtrees;
	vector<string> seq_prec_vector;
	score_pair = 0;

	while(n>1){
		i_save = 0;
		find_maximum(D_aux,i_min,j_min, score_pair);
		
		k = min(i_min,j_min);
		name_kept = D_aux[k].header;
		/*
			Le nouvel item obtenu par agglomération
			i0 et j0 sera positionné à l'indice k
			dans D_aux mis à jour.
		*/
		r = max(i_min,j_min);
		name_remove = D_aux[r].header;
		//--------------------------------------------------
		/*
			Faisons des arbres :D
		*/
		root = build_tree(D_aux, subtrees, seq_prec_vector,score_pair, k, r);
		cout << "treee\n";
		//--------------------------------------------------
	
		//D_aux[k].header += '-' + D_aux[r].header;
		/*
			Mettre à jour les valeurs de la colonne k
			et de la ligne k.
		*/
		for(int i=1;i<n-k;i++){
			D_aux[i+k].ligne[k]=dissim_col(D_aux,i_min,j_min,i-1,i_save);
		
		}
		
		
		int taille_ligne = D_aux[k].ligne.size();
		for(int j=0;j<D_aux[k].ligne.size();j++){
			
			if(j!=r){
			
				D_aux[k].ligne[j]=dissim_lign(D_aux,i_min,j_min,j);
			
			}
		}
		supprimer_ligne(D_aux,r);
		supprimer_colonne(D_aux,r-1);	
		n--;
	}

	//******* FREE MEMORY *******
	subtrees.clear();subtrees.shrink_to_fit();
	seq_prec_vector.clear();seq_prec_vector.shrink_to_fit();
}